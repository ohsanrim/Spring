package sample05;

import java.util.ArrayList;
import java.util.Scanner;

import lombok.Setter;

@Setter
public class SungJukDelete implements SungJuk {
	private ArrayList <SungJukDTO2> list;
	
	@Override
	public void execute() {
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제할 이름 입력:");
		String searchName = sc.nextLine();
		
		int searchUser=0;  //유저가 존재하는지 유무
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getName().equals(searchName)){
				searchUser++; 
				list.remove(i);
				System.out.println("데이터가 삭제되었습니다.");
			}
		}
		if(searchUser==0) System.out.println("찾고자 하는 이름이 존재하지 않습니다.");
		
	}

}
